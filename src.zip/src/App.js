
import './App.css';
import Principal from './Pages/Principal';

function App() {
  return (
    <div className="App">
      <Principal></Principal>
    </div>
  );
}

export default App;
